
package minjeong;

import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.Layer;
import org.openstreetmap.gui.jmapviewer.MapMarkerCircle;
import org.openstreetmap.gui.jmapviewer.MapMarkerDot;

	 
public class Readcsv {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			get();
		}
	
	static void get() {
		Demo de = new Demo();
		KEarthquake value;

	        try {
	         Scanner scanner = new Scanner(new FileReader("C:\\Users\\user\\Desktop\\�ڹ� ����\\EQdata.csv"));//csv���� ��� ���� 
	         String line; 
	         
	         scanner.nextLine();   //ù ��° �� x
	      
	         while(scanner.hasNextLine()) { //���� ���� ���� �Ҷ� ���� �ݺ�
	      
	            line = scanner.nextLine();
	            String[] result = line.split(","); // ��ǥ�� ����
	            
	            SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");   
	            
	            Date dateTime = transFormat.parse(result[0]);
	            double magnitude = Double.parseDouble(result[1]);
	            double latitude = Double.parseDouble(result[2].replace("N",""));
	            double longitude = Double.parseDouble(result[3].replace("E",""));
	            String location = result[4];
	            
	            value = new KEarthquake(dateTime, magnitude, latitude, longitude, location);
	            
	            Layer korea = de.treeMap.addLayer("Korea");
	              de.map().addMapMarker(new MapMarkerCircle(korea, location, new Coordinate(latitude, longitude), magnitude/18));
	              de.map().addMapMarker(new MapMarkerDot(value.magnitudeColor, latitude, longitude));   
	              de.treeMap.getViewer().setDisplayPosition(new Coordinate(latitude, longitude), 7);            
	         }
	        } catch (Exception e) {
	         System.err.println(e);         
	      }
	        de.setVisible(true);

	}

}
